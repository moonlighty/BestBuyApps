
function frmCategoryLists_frmCategoryLists_init_seq0(eventobject){

initCategoryList.call(this);

};

