function initCategoryList(){
	mySegmentData = [];
	var inputParams = {serviceID:"Categories"};
	appmiddlewareinvokerasync(inputParams, callBackCategoryList);
}

function callBackCategoryList(status, callBackResponse){
	kony.print("########## status: "+status);
	// Checking the status 
	if (status == 400){
		// When status is 400, that means we finished calling the service so now we
        // Check the opstatus for 0 meaning it worked
		if (callBackResponse.opstatus == 0){
		
			// Checking to make sure we do have results
			kony.print("########## callBackResponse opstatus : "+callBackResponse.opstatus);
			kony.print("########## callBackResponse categories : "+callBackResponse.categories);
			mySegmentData.push(["Home", callBackResponse.categories]);
			setDataInToSegment();
			
		}
		else{
			 	// The call failed because opstatus was not 0 so we'll alert the user and show that opststus
               // kony.ui.Alert({ message: "Service call failed with opstatus " + foxNewsResponse.opstatus,alertType:constants. ALERT_TYPE_ERROR, alertTitle:"Fox News",yesLabel:"OK"}, {});

		}
	}	
}


function setDataInToSegment(){
	kony.print("########## mySegmentData: "+JSON.stringify(mySegmentData));
	
	if (mySegmentData != null ){
	
		// Setting the WidgetDataMap
		frmCategoryLists.segmentCategoryLists.widgetDataMap={lblTitle:"name"};

		// Setting the data to the segment
		frmCategoryLists.segmentCategoryLists.setVisibility(true);
		frmCategoryLists.segmentCategoryLists.setData(mySegmentData)
		
		
		//frmFoxNews1.segNewsTitle.setVisibility(true);
		//frmFoxNews1.segNewsTitle.setData(mySegmentData);
	}
}
