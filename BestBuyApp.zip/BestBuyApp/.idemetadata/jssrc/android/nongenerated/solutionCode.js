function initCategoryList() {
    var inputParams = {
        serviceID: "Categories"
    };
    appmiddlewareinvokerasync(inputParams, callBackCategoryList);
}

function callBackCategoryList(status, callBackResponse) {
    kony.print("########## status: " + status);
    // Checking the status 
    if (status == 400) {
        // When status is 400, that means we finished calling the service so now we
        // Check the opstatus for 0 meaning it worked
        if (callBackResponse.opstatus == 0) {
            // Checking to make sure we do have results
            kony.print("########## callBackResponse opstatus : " + callBackResponse.opstatus);
        } else {
            // The call failed because opstatus was not 0 so we'll alert the user and show that opststus
            // kony.ui.Alert({ message: "Service call failed with opstatus " + foxNewsResponse.opstatus,alertType:constants. ALERT_TYPE_ERROR, alertTitle:"Fox News",yesLabel:"OK"}, {});
        }
    }
}