//Form JS File
function addWidgetsfrmProductDetails() {
    var btnBack = new kony.ui.Button({
        "id": "btnBack",
        "top": "19dp",
        "left": "28dp",
        "width": "64px",
        "height": "64px",
        "centerX": "10%",
        "centerY": "50%",
        "zIndex": 1,
        "isVisible": true,
        "text": "Button",
        "skin": "CopyslButtonGlossBlue08c69ef24c6f749",
        "focusSkin": "CopyslButtonGlossRed0b9d5889119e944"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var imgLogo = new kony.ui.Image2({
        "id": "imgLogo",
        "top": "6dp",
        "left": "117dp",
        "width": "130px",
        "height": "88px",
        "centerX": "50.00%",
        "centerY": "50%",
        "zIndex": 1,
        "isVisible": true,
        "src": "best_buy_logo.png",
        "imageWhenFailed": null,
        "imageWhileDownloading": null
    }, {
        "padding": [0, 0, 0, 0],
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var FlexContainerHeader = new kony.ui.FlexContainer({
        "id": "FlexContainerHeader",
        "top": "0dp",
        "left": "0dp",
        "width": "100%",
        "height": "15%",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,0]",
        "skin": "CopyslFbox05c554982f1204c",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    FlexContainerHeader.setDefaultUnit(kony.flex.DP)
    FlexContainerHeader.add(
    btnBack, imgLogo);
    var lblProductDesc = new kony.ui.Label({
        "id": "lblProductDesc",
        "top": "0dp",
        "left": "0dp",
        "width": "100%",
        "height": "55%",
        "zIndex": 1,
        "isVisible": true,
        "text": "Product name , Product price, Averageuserreviewincludingimage, Productdescription",
        "skin": "lblProductDesc"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "textCopyable": false
    });
    var lblProductReview = new kony.ui.Label({
        "id": "lblProductReview",
        "top": "55%",
        "left": "0dp",
        "width": "100%",
        "height": "45%",
        "zIndex": 1,
        "isVisible": true,
        "text": "Userreviews-showingthelatest10reviewsinalist.Note:iftherearenoreviews,say\"noreviews\"inthelabel",
        "skin": "CopyslLabel0efa59555abbb4a"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "textCopyable": false
    });
    var FlexContainerProductDetail = new kony.ui.FlexContainer({
        "id": "FlexContainerProductDetail",
        "top": "92dp",
        "left": "0dp",
        "width": "100%",
        "height": "525dp",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,92]",
        "skin": "CopyslFbox037cf0c9fb0e74a",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    FlexContainerProductDetail.setDefaultUnit(kony.flex.DP)
    FlexContainerProductDetail.add(
    lblProductDesc, lblProductReview);
    frmProductDetails.add(
    FlexContainerHeader, FlexContainerProductDetail);
};

function frmProductDetailsGlobals() {
    var MenuId = [];
    frmProductDetails = new kony.ui.Form2({
        "id": "frmProductDetails",
        "enableScrolling": true,
        "bounces": true,
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "pagingEnabled": false,
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "slForm",
        "layoutType": kony.flex.FREE_FORM,
        "addWidgets": addWidgetsfrmProductDetails
    }, {
        "padding": [0, 0, 0, 0],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false,
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "formAnimation": 0
        },
        "outTransitionConfig": {
            "formAnimation": 0
        },
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU
    });
    frmProductDetails.setDefaultUnit(kony.flex.DP);
};