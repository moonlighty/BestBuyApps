//Form JS File
function frmCategoryLists_frmCategoryLists_init_seq0(eventobject) {
    initCategoryList.call(this);
};

function addWidgetsfrmCategoryLists() {
    var btnBack = new kony.ui.Button({
        "id": "btnBack",
        "top": "19dp",
        "left": "28dp",
        "width": "64px",
        "height": "64px",
        "centerX": "10%",
        "centerY": "50%",
        "zIndex": 1,
        "isVisible": true,
        "text": "Button",
        "skin": "CopyslButtonGlossBlue08c69ef24c6f749",
        "focusSkin": "CopyslButtonGlossRed0b9d5889119e944"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var imgLogo = new kony.ui.Image2({
        "id": "imgLogo",
        "top": "6dp",
        "left": "117dp",
        "width": "130px",
        "height": "88px",
        "centerX": "50.00%",
        "centerY": "50%",
        "zIndex": 1,
        "isVisible": true,
        "src": "best_buy_logo.png",
        "imageWhenFailed": null,
        "imageWhileDownloading": null
    }, {
        "padding": [0, 0, 0, 0],
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var FlexContainerHeader = new kony.ui.FlexContainer({
        "id": "FlexContainerHeader",
        "top": "0dp",
        "left": "0dp",
        "width": "100%",
        "height": "15%",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,0]",
        "skin": "CopyslFbox05c554982f1204c",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    FlexContainerHeader.setDefaultUnit(kony.flex.DP)
    FlexContainerHeader.add(
    btnBack, imgLogo);
    var btnSearch = new kony.ui.Button({
        "id": "btnSearch",
        "top": "20%",
        "left": "65%",
        "width": "30%",
        "height": "100px",
        "centerY": "29%",
        "zIndex": 1,
        "isVisible": true,
        "text": "Search",
        "skin": "CopyslButtonGlossBlue0331bc76efc5d40",
        "focusSkin": "slButtonGlossRed"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var tbxSearch = new kony.ui.TextBox2({
        "id": "tbxSearch",
        "top": "10%",
        "left": "5dp",
        "width": "217dp",
        "height": "100px",
        "zIndex": 1,
        "isVisible": true,
        "text": null,
        "secureTextEntry": false,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "enter keywords...",
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "skin": "CopyslTextBox036c490cb58ba48"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "autoCorrect": false,
        "autoComplete": false
    });
    var lblNavigation = new kony.ui.Label({
        "id": "lblNavigation",
        "top": "51dp",
        "left": "16dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Home",
        "skin": "slLabel"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "textCopyable": false
    });
    var FlexContainerSearch = new kony.ui.FlexContainer({
        "id": "FlexContainerSearch",
        "top": "93dp",
        "left": "0dp",
        "width": "100%",
        "height": "14.59%",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,93]",
        "skin": "CopyslFbox0badfd87d41574a",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    FlexContainerSearch.setDefaultUnit(kony.flex.DP)
    FlexContainerSearch.add(
    btnSearch, tbxSearch, lblNavigation);
    var segmentCategoryListsbox = new kony.ui.FlexContainer({
        "id": "segmentCategoryListsbox",
        "isVisible": true,
        "orientation": null,
        "width": "100%",
        "height": "40dp",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": null
    }, {});
    var segmentCategoryLists = new kony.ui.SegmentedUI2({
        "id": "segmentCategoryLists",
        "top": "183dp",
        "left": "0dp",
        "width": "100%",
        "height": "433dp",
        "zIndex": 1,
        "isVisible": true,
        "retainSelection": false,
        "widgetDataMap": {
            "lblTitle": "lblTitle"
        },
        "Location": "[0,183]",
        "rowTemplate": segmentCategoryListsbox,
        "rowSkin": "Copyseg02e7c959aebe84d",
        "rowFocusSkin": "seg2Focus",
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "separatorRequired": true,
        "separatorThickness": 1,
        "separatorColor": "64646400",
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "groupCells": false,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});
    var lblTitle = new kony.ui.Label({
        "id": "lblTitle",
        "top": "0dp",
        "left": "1dp",
        "width": "439dp",
        "height": "26dp",
        "zIndex": 1,
        "isVisible": true
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {
        "textCopyable": false
    });
    segmentCategoryListsbox.add(
    lblTitle);
    frmCategoryLists.add(
    FlexContainerHeader, FlexContainerSearch, segmentCategoryLists);
};

function frmCategoryListsGlobals() {
    var MenuId = [];
    frmCategoryLists = new kony.ui.Form2({
        "id": "frmCategoryLists",
        "enableScrolling": true,
        "bounces": true,
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "pagingEnabled": false,
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "slForm",
        "init": frmCategoryLists_frmCategoryLists_init_seq0,
        "layoutType": kony.flex.FREE_FORM,
        "addWidgets": addWidgetsfrmCategoryLists
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false,
        "inTransitionConfig": {
            "formTransition": "None"
        },
        "outTransitionConfig": {
            "formTransition": "None"
        }
    });
    frmCategoryLists.setDefaultUnit(kony.flex.DP);
};