//Form JS File
function addWidgetsfrmProductLists() {
    var btnBack = new kony.ui.Button({
        "id": "btnBack",
        "top": "19dp",
        "left": "28dp",
        "width": "64px",
        "height": "64px",
        "centerX": "10%",
        "centerY": "50%",
        "zIndex": 1,
        "isVisible": true,
        "text": "Button",
        "skin": "CopyslButtonGlossBlue08c69ef24c6f749",
        "focusSkin": "CopyslButtonGlossRed0b9d5889119e944"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var imgLogo = new kony.ui.Image2({
        "id": "imgLogo",
        "top": "6dp",
        "left": "117dp",
        "width": "130px",
        "height": "88px",
        "centerX": "50.00%",
        "centerY": "50%",
        "zIndex": 1,
        "isVisible": true,
        "src": "best_buy_logo.png",
        "imageWhenFailed": null,
        "imageWhileDownloading": null
    }, {
        "padding": [0, 0, 0, 0],
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var FlexContainerHeader = new kony.ui.FlexContainer({
        "id": "FlexContainerHeader",
        "top": "0dp",
        "left": "0dp",
        "width": "100%",
        "height": "15%",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,0]",
        "skin": "CopyslFbox05c554982f1204c",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    FlexContainerHeader.setDefaultUnit(kony.flex.DP)
    FlexContainerHeader.add(
    btnBack, imgLogo);
    var lblNavigation = new kony.ui.Label({
        "id": "lblNavigation",
        "top": "6dp",
        "left": "11dp",
        "width": "1013px",
        "zIndex": 1,
        "isVisible": true,
        "text": "category : DVD Player",
        "skin": "CopyslLabel0d400ad623fbf4b"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "textCopyable": false
    });
    var FlexContainerNavigation = new kony.ui.FlexContainer({
        "id": "FlexContainerNavigation",
        "top": "93dp",
        "left": "0dp",
        "width": "100%",
        "height": "7.29%",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,93]",
        "skin": "CopyslFbox0badfd87d41574a",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    FlexContainerNavigation.setDefaultUnit(kony.flex.DP)
    FlexContainerNavigation.add(
    lblNavigation);
    var segmentCategoryListsbox = new kony.ui.FlexContainer({
        "id": "segmentCategoryListsbox",
        "isVisible": true,
        "orientation": null,
        "width": "100%",
        "height": "40dp",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": null
    }, {});
    var segmentCategoryLists = new kony.ui.SegmentedUI2({
        "id": "segmentCategoryLists",
        "top": "138dp",
        "left": "0dp",
        "width": "100%",
        "height": "395dp",
        "zIndex": 1,
        "isVisible": true,
        "retainSelection": false,
        "Location": "[0,138]",
        "rowTemplate": segmentCategoryListsbox,
        "rowSkin": "Copyseg02e7c959aebe84d",
        "rowFocusSkin": "seg2Focus",
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "separatorRequired": true,
        "separatorThickness": 1,
        "separatorColor": "64646400",
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "groupCells": false,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});
    segmentCategoryListsbox.add();
    var btnPrev = new kony.ui.Button({
        "id": "btnPrev",
        "top": "30%",
        "left": "6dp",
        "width": "300px",
        "height": "100px",
        "zIndex": 1,
        "isVisible": true,
        "text": "<< Prev",
        "skin": "CopyslButtonGlossBlue01ab6b15ce2b243",
        "focusSkin": "slButtonGlossRed"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var btnNext = new kony.ui.Button({
        "id": "btnNext",
        "top": "30.00%",
        "left": "249dp",
        "width": "300px",
        "height": "100px",
        "zIndex": 1,
        "isVisible": true,
        "text": "Next >>",
        "skin": "CopyslButtonGlossBlue03549988094b647",
        "focusSkin": "slButtonGlossRed"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {});
    var lblPagination = new kony.ui.Label({
        "id": "lblPagination",
        "top": "40%",
        "left": "113dp",
        "width": "388px",
        "zIndex": 1,
        "isVisible": true,
        "text": "Page 1 of 3",
        "skin": "CopyslLabel0c2aeb81b800447"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "textCopyable": false
    });
    var FlexContainerPagination = new kony.ui.FlexContainer({
        "id": "FlexContainerPagination",
        "top": "533dp",
        "left": "0dp",
        "width": "100%",
        "height": "79dp",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,533]",
        "skin": "CopyslFbox08ee88c27be5247",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    FlexContainerPagination.setDefaultUnit(kony.flex.DP)
    FlexContainerPagination.add(
    btnPrev, btnNext, lblPagination);
    frmProductLists.add(
    FlexContainerHeader, FlexContainerNavigation, segmentCategoryLists, FlexContainerPagination);
};

function frmProductListsGlobals() {
    var MenuId = [];
    frmProductLists = new kony.ui.Form2({
        "id": "frmProductLists",
        "enableScrolling": true,
        "bounces": true,
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "pagingEnabled": false,
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "slForm",
        "layoutType": kony.flex.FREE_FORM,
        "addWidgets": addWidgetsfrmProductLists
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false,
        "inTransitionConfig": {
            "formTransition": "None"
        },
        "outTransitionConfig": {
            "formTransition": "None"
        }
    });
    frmProductLists.setDefaultUnit(kony.flex.DP);
};