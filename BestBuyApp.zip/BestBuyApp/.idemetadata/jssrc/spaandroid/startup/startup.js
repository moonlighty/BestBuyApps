//startup.js file
var appConfig = {
    appId: "BestBuyApp",
    appName: "BestBuyApp",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.175.70.129",
    serverPort: "8080",
    secureServerPort: "443",
    url: "http://10.175.70.129:8080/middleware/MWServlet",
    secureurl: "https://10.175.70.129:443/middleware/MWServlet",
    middlewareContext: "middleware"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    frmCategoryListsGlobals();
    frmProductDetailsGlobals();
    frmProductListsGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        APILevel: 6000
    })
};

function themeCallBack() {
    kony.application.setApplicationInitializationEvents({
        init: appInit,
        showstartupform: function() {
            frmCategoryLists.show();
        }
    });
};

function loadResources() {
    kony.theme.packagedthemes(
    ["default"]);
    globalhttpheaders = {};
    callAppMenu();
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
};

function initializeApp() {
    kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
    //If default locale is specified. This is set even before any other app life cycle event is called.
    loadResources();
};